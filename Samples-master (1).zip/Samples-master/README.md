Samples
=======

Sample applications and projects, which demonstrate applinks production and troubleshooting code

Samples includes two apps:
1. outbound applink sample app: AppLinkPasteboard
2. inbound applink sample app: PrimeNumbers

After installing the two apps on the same device,  you can run the demo of how applinks: 
1. In PrimeNumbers,  get the copy link on the top right (from the Number Detail Page or Definition Page) in Clipboard.
2. Paste the link into AppLinkPasteboard app,   then click on the item then open the PrimeNumber App directly from AppLinkPasteboard app. 
3. In AppLinkPasteboard, click on the Detail (tilt or button) and see more information about the appLink. note that the App Link is already resolved at the page. 

For more details, you can see README file in each app project.
