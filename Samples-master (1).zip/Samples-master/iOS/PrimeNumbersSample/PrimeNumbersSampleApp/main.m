//
//  main.m
//  PrimeNumbers
//
//  Created by Gen Wang on 5/12/14.
//  Copyright (c) 2014 applinks.org. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PNAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PNAppDelegate class]));
    }
}
