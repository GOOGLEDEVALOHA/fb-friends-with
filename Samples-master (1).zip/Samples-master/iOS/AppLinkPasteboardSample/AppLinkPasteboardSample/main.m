//
//  main.m
//  AppLinkPasteboard
//
//  Created by Gen Wang on 5/14/14.
//  Copyright (c) 2014 applinks.org. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ALPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ALPAppDelegate class]));
    }
}
